class CalculadoraBonificacao {
}